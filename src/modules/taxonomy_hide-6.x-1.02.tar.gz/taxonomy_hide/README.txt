TAXONOMY HIDE
=============

Description:
------------

This module allows you to specify vocabularies whose terms will not be
listed when you view nodes. Additionally, it can group terms by vocabulary.

Authors
-------
Tomas Mandys (tomas.mandys@2p.cz)
Frodo Looijaard (drupal@frodo.looijaard.name)
Bruno Massa (http://drupal.org/user/67164)
